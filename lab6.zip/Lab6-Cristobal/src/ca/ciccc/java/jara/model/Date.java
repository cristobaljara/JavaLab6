package ca.ciccc.java.jara.model;

/**
 * 
 * @author jara We define the class
 */
public class Date {
	/**
	 * 
	 * we define instance variables for int day, month and year
	 */
	private int day;
	private int month;
	private int year;
	/**
	 * 
	 * we define JANUARY Constant to avoid magic numbers
	 */
	public static final int JANUARY = 1;
	/**
	 * 
	 * we define FEBRUARY Constant to avoid magic numbers
	 */
	public static final int FEBRUARY = 2;
	/**
	 * 
	 * we define MARCH Constant to avoid magic numbers
	 */
	public static final int MARCH = 3;
	/**
	 * 
	 * we define APRIL Constant to avoid magic numbers
	 */
	public static final int APRIL = 4;
	/**
	 * 
	 * we define MAY Constant to avoid magic numbers
	 */
	public static final int MAY = 5;
	/**
	 * 
	 * we define JUNE Constant to avoid magic numbers
	 */
	public static final int JUNE = 6;
	/**
	 * 
	 * we define JULY Constant to avoid magic numbers
	 */
	public static final int JULY = 7;
	/**
	 * 
	 * we define AUGUST Constant to avoid magic numbers
	 */
	public static final int AUGUST = 8;
	/**
	 * 
	 * we define SEPTEMBER Constant to avoid magic numbers
	 */
	public static final int SEPTEMBER = 9;
	/**
	 * 
	 * we define OCTOBER Constant to avoid magic numbers
	 */
	public static final int OCTOBER = 10;
	/**
	 * 
	 * we define NOVEMBER Constant to avoid magic numbers
	 */
	public static final int NOVEMBER = 11;
	/**
	 * 
	 * we define DECEMBER Constant to avoid magic numbers
	 */
	public static final int DECEMBER = 12;

	/**
	 * 
	 * @param year
	 *            we set year
	 * @param month
	 *            we set month
	 * @param day
	 *            we set day
	 * @throws Exception
	 *             we set throws exception
	 */
	public Date(int year, int month, int day) throws Exception {
		setYear(year);
		setMonth(month);
		setDay(day);
	}

	/**
	 * We return day related with getDay
	 * 
	 * @return we set the getter to return day
	 */
	public final int getDay() {
		return day;
	}

	/**
	 * 
	 * @param day
	 *            we create if condition to set limits for days
	 * @throws Exception
	 *             we throw exception when we type a number outside of limits
	 */
	public final void setDay(int day) throws Exception {
		int maxDay = getNumOfDaysInMonth();

		if (day > 0 && day <= maxDay) {
			this.day = day;
		} else {
			throw new Exception("You're outside of the day's limits");
		}
	}

	/**
	 * We return month related with getMonth
	 * 
	 * @return we set the getter to return month
	 */
	public final int getMonth() {
		return month;
	}

	/**
	 * We create a final string condition to get 12 months
	 * 
	 * @return we return each if and else if condition defining 12 months to return
	 */
	public final String getMonthName() {
		if (this.getMonth() == 1) {
			return "January";
		} else if (this.getMonth() == 2) {
			return "Febraury";
		} else if (this.getMonth() == 3) {
			return "March";
		} else if (this.getMonth() == 4) {
			return "April";
		} else if (this.getMonth() == 5) {
			return "May";
		} else if (this.getMonth() == 6) {
			return "June";
		} else if (this.getMonth() == 7) {
			return "July";
		} else if (this.getMonth() == 8) {
			return "August";
		} else if (this.getMonth() == 9) {
			return "September";
		} else if (this.getMonth() == 10) {
			return "October";
		} else if (this.getMonth() == 11) {
			return "November";
		} else if (this.getMonth() == 12) {
			return "December";
		}
		return "unknown";
	}

	/**
	 * 
	 * @param month
	 *            we create if condition to set limits for months
	 * @throws Exception
	 *             we throw exception when we type a number outside of limits
	 */
	public final void setMonth(int month) throws Exception {
		if (month >= 1 && month <= 12) {
			this.month = month;
		} else {
			throw new Exception("You're outside of the month's limits");
		}
	}

	/**
	 * We return year related with getYear
	 * 
	 * @return we set the getter to return year
	 */
	public final int getYear() {
		return year;
	}

	/**
	 * We are refering to the year that is inside of this class
	 * 
	 * @param year
	 *            we will be set
	 */
	public final void setYear(int year) {
		this.year = year;
	}

	/**
	 * returns the day of the week, the month and year for a specified date
	 * 
	 * @return the phrase that merge month, day and year that we received
	 * @throws Exception
	 *             for getDayOfTheWeek() method
	 */
	public String getDayOfTheWeek() throws Exception {
		int total = 0;
		int numbers = this.getYear();
		int last = numbers % 100;
		int seven = last / 12;
		int five = last - seven * 12;
		int four = five / 4;

		total += seven;
		total += five;
		total += four;
		total += this.getDay();

		int monthcode = 0;

		if (this.getMonth() == 1) {
			monthcode = 1;
		} else if (this.getMonth() == 2) {
			monthcode = 4;
		} else if (this.getMonth() == 3) {
			monthcode = 4;
		} else if (this.getMonth() == 4) {
			monthcode = 0;
		} else if (this.getMonth() == 5) {
			monthcode = 2;
		} else if (this.getMonth() == 6) {
			monthcode = 5;
		} else if (this.getMonth() == 7) {
			monthcode = 0;
		} else if (this.getMonth() == 8) {
			monthcode = 3;
		} else if (this.getMonth() == 9) {
			monthcode = 6;
		} else if (this.getMonth() == 10) {
			monthcode = 1;
		} else if (this.getMonth() == 11) {
			monthcode = 4;
		} else if (this.getMonth() == 12) {
			monthcode = 6;
		} else {

		}

		if (isLeapYear() && (getMonth() == 1 || getMonth() == 2)) {
			monthcode -= 1;
		}

		if (year >= 1600 && year <= 1699) {
			monthcode += 6;
		}

		if (year >= 1700 && year <= 1799) {
			monthcode += 4;
		}

		if (year >= 1800 && year <= 1899) {
			monthcode += 2;
		}

		if (year >= 2000 && year <= 2099) {
			monthcode += 6;
		}
		if (year >= 2100 && year <= 2199) {
			monthcode += 4;
		}

		total += monthcode;

		int result = total % 7;

		String weekday = "unknown";
		if (result == 0) {

			weekday = "Saturday";
		}

		if (result == 1) {

			weekday = "Sunday";
		}

		if (result == 2) {

			weekday = "Monday";
		}

		if (result == 3) {

			weekday = "Tuesday";
		}

		if (result == 4) {

			weekday = "Wednesday";
		}
		if (result == 5) {

			weekday = "Thursday";
		}
		if (result == 6) {

			weekday = "Friday";
		}

		return getMonthName() + " " + getDay() + ", " + getYear() + " was on " + weekday + ".";
	}

	/**
	 * 
	 * @return true if is leap year, false on the contrary
	 */
	private boolean isLeapYear() {
		if (year % 4 != 0) {
			return false;
		} else if (year % 400 == 0) {
			return true;
		} else if (year % 100 == 0) {
			return false;
		} else {
			return true;
		}
	}

	public int getNumOfDaysInMonth() {
		int numberOfDays = 0;

		switch (this.month) {
		case JANUARY:
		case MARCH:
		case MAY:
		case JULY:
		case AUGUST:
		case OCTOBER:
		case DECEMBER:
			numberOfDays = 31;
			break;
		case APRIL:
		case JUNE:
		case SEPTEMBER:
		case NOVEMBER:
			numberOfDays = 30;
			break;
		case FEBRUARY:
			numberOfDays = isLeapYear() ? 29 : 28;
			break;
		}

		return numberOfDays;
	}
}
