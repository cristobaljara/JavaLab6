package ca.ciccc.java.jara.controller;

import ca.ciccc.java.jara.model.Date;
import ca.ciccc.java.jara.model.InputReader;

public class Driver {

	public static void main(String[] args) {
		Date day;
		InputReader inputcris = new InputReader();

		try {
			day = new Date(2017, 12, 6);

			System.out.print("Type the day, please: ");
			day.setDay(inputcris.getIntInput());
			System.out.print("Type the month, please: ");
			day.setMonth(inputcris.getIntInput());
			System.out.print("Type the year, please: ");
			day.setYear(inputcris.getIntInput());

			System.out.println(day.getDayOfTheWeek());
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
	}
}
